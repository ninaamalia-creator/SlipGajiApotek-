# Slip Gaji Apotek

Aplikasi Android slip gaji untuk Apotek Karima & Apotek Ampuh.
Cetak langsung ke printer termal Bluetooth 58 mm (ESC/POS, mis. MP-58A).
Tampilan aplikasi ada di app/src/main/assets/index.html.
